Config              = {}
Config.DrawDistance = 6.0
Config.ZoneSize     = {x = 3.0, y = 3.0, z = 2.0}
Config.MarkerColor  = {r = 100, g = 100, b = 204}
Config.MarkerType   = 27
Config.Locale       = 'en'

Config.Zones = {
	{x = -721.87 , y = -99.74, z = 38.33} 
}
  