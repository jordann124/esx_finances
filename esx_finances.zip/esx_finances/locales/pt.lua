Locales['en'] = {
  ['invoices'] = 'Finances',
  ['invoices_item'] = '$%s',
  ['received_invoice'] = 'You ~r~recebeu~s~ an invoice',
  ['paid_invoice'] = 'You ~g~paid~s~ an invoice in the finances of ~r~$%s~s~',
  ['received_payment'] = 'You ~g~recebeu~s~ a payment of ~r~$%s~s~',
  ['player_not_online'] = 'Player is not logged in',
  ['no_money'] = 'You do not have enough money',
  ['target_no_money'] = 'The player ~r~there is not~s~ enough money!',
  ['financas'] = 'Finances',
  ['access_fincancas'] = '[E] to open the menu',
}
